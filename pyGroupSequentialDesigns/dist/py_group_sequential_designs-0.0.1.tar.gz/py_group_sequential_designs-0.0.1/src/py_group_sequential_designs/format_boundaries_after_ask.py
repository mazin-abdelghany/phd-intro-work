def format_boundaries_after_ask(result):
    upper_bounds = np.array(result[0][0:3])
    lower_bounds = np.concatenate((result[0][3:5], [result[0][2]]))
    n_patients = np.array(result[0][5])

    return [
        upper_bounds,
        lower_bounds,
        n_patients
    ]